# setup.py
from setuptools import setup, find_packages

setup(
    name="Topsis-FirstName-RollNumber",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        # List your dependencies here
        # e.g., 'requests', 'numpy',
    ],
    entry_points={
        'console_scripts': [
            # 'script_name=module:function',
        ],
    },
)
