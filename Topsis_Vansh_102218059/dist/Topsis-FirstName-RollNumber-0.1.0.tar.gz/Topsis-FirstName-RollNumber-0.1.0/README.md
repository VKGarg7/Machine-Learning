# Topsis-FirstName-RollNumber

This package implements the TOPSIS method for multi-criteria decision analysis. It allows users to rank alternatives based on their scores.
